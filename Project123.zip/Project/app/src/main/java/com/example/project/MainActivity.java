package com.example.project;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.MenuItemCompat;

import android.renderscript.Sampler;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {
    //
    String[] nameArray = {"Kadai Chicken", "Biryani", "Chilli Chicken", "Paneer Butter Masala"};
//


    String[] infoArray = {
            "Spicy and flavorful", "Hyderbadi special", "Chinese special", "Kebabs and Tikkis Recipe"

    };
    ListView listView;
    // ListView search_food;

    ArrayAdapter<String> adapter;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // search_food=(ListView) findViewById(R.id.search_food);
        Integer[] imageArray = new Integer[]{R.drawable.kadai,
                R.drawable.biriyani, R.drawable.chilli, R.drawable.panner};
        listView = (ListView) findViewById(R.id.listviewID);

        Person whatever = new Person(this, nameArray, infoArray, imageArray);
        listView = (ListView) findViewById(R.id.listviewID);
        listView.setAdapter(whatever);
        // search_food.setAdapter(adapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate menu with items using MenuInflator
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.search_engine, menu);

        // Initialise menu item search bar
        // with id and take its object
        MenuItem searchViewItem
                = menu.findItem(R.id.search_bar);
        SearchView searchView
                = (SearchView) MenuItemCompat
                .getActionView(searchViewItem);

        // attach setOnQueryTextListener
        // to search view defined above
        searchView.setOnQueryTextListener(
                new SearchView.OnQueryTextListener() {

                    @Override
                    public boolean onQueryTextSubmit(String s) {
                        if (Arrays.asList(nameArray).contains(s)) {
                            adapter.getFilter().filter(s);
                        } else {
                            // Search query not found in List View
                            Toast
                                    .makeText(MainActivity.this,
                                            "Not found",
                                            Toast.LENGTH_LONG)
                                    .show();
                        }
                        return false;
                    }

                    @Override
                    public boolean onQueryTextChange(String newText) {
                        adapter.getFilter().filter(newText);
                        return false;
                    }

                    // Override onQueryTextSubmit method
                    // which is call
                    // when submitquery is searched
//        SearchView mySearchView;
//        mySearchView = (SearchView)findViewById(R.id.search_view);
//        mySearchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {


                });


        listView.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    Intent myIntent = new Intent(view.getContext(), DetiledActivity.class);
                    startActivityForResult(myIntent, 0);
                }
                if (position == 1) {
                    Intent myIntent = new Intent(view.getContext(), ActivityTwo.class);
                    startActivityForResult(myIntent, 0);
                }

                if (position == 2) {
                    Intent myIntent = new Intent(view.getContext(), ActivityThree.class);
                    startActivityForResult(myIntent, 0);
                }
                if (position == 3) {
                    Intent myIntent = new Intent(view.getContext(), ActivityFour.class);
                    startActivityForResult(myIntent, 0);
                }
            }
        });
        return super.onCreateOptionsMenu(menu);
    }
    }



