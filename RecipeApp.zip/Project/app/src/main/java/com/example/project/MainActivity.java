package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.renderscript.Sampler;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
//
//    String [] nameArray = {"Veena","Ansalna","Praveena","Amal"};
//

//    nameArray[0] = "Veena"
//    nameArray[1] = "Ansalna";
//    nameArray[2] = "Praveena";
//    nameArray[3] = "Amal";

    //    String[] infoArray = {
//            "Hello", "Hi","Namaste","Hey!!!"
//
//    };
    ListView listView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//    int position;
//    Integer[] imageArray = new Integer[]{R.drawable.veenaimage,
//            R.drawable.ansalna,R.drawable.praveena,R.drawable.amalj};
        listView = (ListView)findViewById(R.id.listviewID);
        String[] Values = new String[]{"Veena", "Ansalna", "Praveena", "Amal"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, android.R.id.text1, Values);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    Intent myIntent = new Intent(view.getContext(), DetiledActivity.class);
                    startActivityForResult(myIntent, 0);
                }
                if (position== 1) {
                    Intent myIntent = new Intent(view.getContext(), ActivityTwo.class);
                    startActivityForResult(myIntent, 0);
                }

                if (position== 2) {
                    Intent myIntent = new Intent(view.getContext(), ActivityThree.class);
                    startActivityForResult(myIntent, 0);
                }
                if (position== 3) {
                    Intent myIntent = new Intent(view.getContext(), ActivityFour.class);
                    startActivityForResult(myIntent, 0);
                }
            }
        });
    }
}
//            @Override
//            public void onItemClick(AdapterView<?> parent, View view, int position,
//                                    long id) {
//                Intent intent = new Intent(MainActivity.this, DetiledActivity.class);
//                String message = nameArray[position];
//                intent.putExtra("name", message);
//                startActivity(intent);
//            }
//        });
//
//
//        }

//    @Override
//    public void onClick(View v) {
//
//            switch (position) {
//                case R.drawable.veenaimage:
//                    Intent i = new Intent(MainActivity.this, ActivityDetail.class);
//
//                    String message = nameArray[position];
//                    i.putExtra("Veena", message);
//                    startActivity(i);
//                    break;
//
//                case R.drawable.ansalna:
//                    Toast.makeText(MainActivity.this, "One-button", Toast.LENGTH_LONG).show();
//                    break;
//                case R.drawable.praveena:
//                    Toast.makeText(MainActivity.this, "three-button", Toast.LENGTH_LONG).show();
//                    break;
//            }
//
//        }
//
//    }
//
//    public ArrayAdapter<String> getAdapter() {
//        return adapter;
//    }

